*pt-Br translation of Allumeria by Unomelon Games.*

# Instalação
Simplesmente coloque a pasta "pt-BR" dentro de allumeria\res\translations.
# Créditos
**Tradução:** SomaSnacks
**Revisão:** thecheolhyeol, MarcioAlpha

